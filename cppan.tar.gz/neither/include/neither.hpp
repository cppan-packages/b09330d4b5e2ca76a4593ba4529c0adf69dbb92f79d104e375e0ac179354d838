#ifndef NEITHER_NEITHER_HPP
#define NEITHER_NEITHER_HPP

#include <neither/either.hpp>
#include <neither/lift.hpp>
#include <neither/maybe.hpp>
#include <neither/traits.hpp>
#include <neither/try.hpp>

#endif
